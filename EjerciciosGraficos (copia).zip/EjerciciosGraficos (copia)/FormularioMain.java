package EjerciciosGraficos;

public class FormularioMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Formulario f1=new Formulario();
	}

}
