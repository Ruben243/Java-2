package EjerciciosGraficos;

public class AplicacionEuroConversor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EuroConversor v1=new EuroConversor();

	}

}
