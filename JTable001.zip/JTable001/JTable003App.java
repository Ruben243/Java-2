package JTable001;

public class JTable003App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      JTable003 t3=new JTable003();
	}

}
