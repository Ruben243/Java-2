package JTable001;

public class JTable001App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		JTable001 t1=new JTable001();

	}

}
