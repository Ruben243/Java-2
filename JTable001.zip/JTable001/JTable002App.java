package JTable001;

public class JTable002App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JTable002 t2=new JTable002();
	}

}
