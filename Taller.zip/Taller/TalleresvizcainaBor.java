package Taller;

import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

public class TalleresvizcainaBor extends JFrame implements ActionListener{
	
	 private JLabel h3,Ldni;
     private JTextField Tdni;
     private JButton Bbor;
     private JTable regis;
 	 private JScrollPane barra;
     private Talleresvizcaina inicio;
     private JMenuBar bMenu;
     private JMenu mOut;
     private JMenuItem smOUt;
	
     
     
     
     
     
     
	public TalleresvizcainaBor(Talleresvizcaina v) throws HeadlessException {
		super("VENTANA DE BORRADO");
		inicio=v;
		h3=new JLabel("TALLERES LA VIZCAINA");
		Ldni=new JLabel("DNI");
		
		Tdni=new JTextField(15);
		
		bMenu=new JMenuBar();
		mOut=new JMenu("Salir");
		smOUt=new JMenuItem("Cerrar");
		
		Bbor=new JButton("BORRAR");
		
		h3.setBounds(075,8,150,27);
		Ldni.setBounds(075,40,77,27);
		Tdni.setBounds(170,40,130,27);
		Bbor.setBounds(170,70,77,27);
		
		this.getContentPane().setLayout(null);
		this.setBounds(250,280,700,600);
		
		 mOut.add(smOUt);
	     bMenu.add(mOut);
	     this.setJMenuBar(bMenu);
		
		this.add(h3);
		this.add(Ldni);
		this.add(Tdni);
		this.add(Bbor);
		
		Bbor.addActionListener(this);
		smOUt.addActionListener(this);
		setVisible(true);
		
	}









	@Override
	public void actionPerformed(ActionEvent b) {
		// TODO Auto-generated method stub
		  String eventoComando =b.getActionCommand();
			
			if(b.getSource() instanceof JButton){
				if(eventoComando=="BORRAR"){
					try{
						
						String driver="com.mysql.cj.jdbc.Driver";
						String url="jdbc:mysql://asata400:3306/Tallerruben";
						String user="root";
						String password="toor";
						Connection con=null;
						PreparedStatement ps=null;
						ResultSet rs=null;
						String sql="select * from taller where dni=?";
						String dni=Tdni.getText();
						Class.forName(driver);
						Vector aux=null;
					    Vector filas=new Vector();
					    Vector columnas=new Vector();
					    columnas.addElement("dni");
					    columnas.addElement("Nombre");
					    columnas.addElement("apellidos");
					    columnas.addElement("ciudad");
					    columnas.addElement("salario");
						con=DriverManager.getConnection(url,user,password);
						ps=con.prepareStatement(sql);
					    ps.setString(1,dni);
				        rs=ps.executeQuery();
			            while(rs.next()){
			            	aux=new Vector();
							 aux.addElement(""+rs.getString("dni"));
							 aux.addElement(rs.getString("Nombre"));
							 aux.addElement(""+rs.getString("apellidos"));
							 aux.addElement(""+rs.getString("ciudad"));
							 aux.addElement(""+rs.getString("salario"));

					         filas.add(aux);
			           		  	    
							       
								        
			               }
				        
			            regis=new JTable(filas,columnas);
					    barra=new JScrollPane(regis);
					    barra.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
					    barra.setBounds(075,200,500,500);
						add(barra);
						rs.close();
			           
						 ResultSet consulta=null;
						 Connection ct=null;
						 PreparedStatement st=null;
					     String sql2="delete from taller where dni=?";
				         Class.forName(driver);
						 ct=DriverManager.getConnection(url, user, password);
						 int x=0;
						 String dni2=Tdni.getText();
						 st=ct.prepareStatement(sql2);
						 st.setString(1,dni2);
						 x=st.executeUpdate();
						
						 System.out.println("Se han eliminado " + x + " registros");
						 ct.close();
				     }catch(Exception a){
				    	 System.out.println("ERROR "+ a.getMessage());
				    
				    	 
				     }
					
						
					
			   }
			
	      }else if (b.getSource() instanceof JMenuItem){
				if(eventoComando.equals("Cerrar")){
			    	inicio.setVisible(true);
			    	this.dispose();
			    	
			    	
			    	
			        }
	 	
	 
		  
		  
		  
	  
	 }

   }
}
