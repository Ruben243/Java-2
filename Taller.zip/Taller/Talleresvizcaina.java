package Taller;

import java.awt.Color;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

import baseDatos.VentanaInsertar;
import baseDatos.VentanabuscarPro;

public class Talleresvizcaina extends JFrame implements ActionListener {
     private JLabel h3,Ldni,Lnom,Lape,Lcity,Lsalar,logo;
     private JTextField Tdni,Tnom,Tape,Tcity,Tsalar;
     private JButton Bnew,Bfind;
     private JComboBox lugares;
     private  String []ciudades={"Madrid","Barcelona","Oviedo","Otra"};
     private JMenuBar bMenu;
     private JMenu mFind,mOdi,mOut;
     private JMenuItem smCity,smNom,smBor,smOUt;

     
     
	
	
	
	public Talleresvizcaina() throws HeadlessException {
		super("TALLER");
		
		h3=new JLabel("TALLERES LA VIZCAINA");
		Ldni=new JLabel("DNI");
		Lnom=new JLabel("NOMBRE");
		Lape=new JLabel("APELLIDOS");
		Lcity=new JLabel("CIUDAD");
		Lsalar=new JLabel("SALARIO");
		logo=new JLabel(new ImageIcon("C:/Users/AsataTarde/Desktop/taller.jpg"));
		
		
		Tdni=new JTextField(15);
		Tnom=new JTextField(15);
		Tape=new JTextField(15);
		lugares=new JComboBox(ciudades);
        Tsalar=new JTextField(15);
		
		
		Bfind=new JButton("BUSCAR");
		Bnew=new JButton("NUEVO");
		
		bMenu=new JMenuBar();
		mFind=new JMenu("Buscar");
		mOdi=new JMenu("Modificaciones");
		mOut=new JMenu("Salir");
		smOUt=new JMenuItem("Cerrar");
		smCity=new JMenuItem("B-CIUDAD",'c');
		smNom=new JMenuItem("B-NOMBRE",'n');
		smBor=new JMenuItem("Borrar",'b');
		
		mFind.add(smCity);
		mFind.add(smNom);
		mOdi.add(smBor);
		mOut.add(smOUt);
		
		bMenu.add(mFind);
		bMenu.add(mOdi);
		bMenu.add(mOut);
		
		 this.setJMenuBar(bMenu);
		
		
		this.getContentPane().setLayout(null);
		this.setBounds(250,280,700,600);
		
		h3.setBounds(075,8,150,27);
		Ldni.setBounds(075,40,77,27);
		Tdni.setBounds(170,40,130,27);
		Lnom.setBounds(075,80,77,27);
		Tnom.setBounds(170,80,130,27);
		Lape.setBounds(075,120,77,27);
		Tape.setBounds(170,120,130,27);
		Lcity.setBounds(075,160,77,27);
		lugares.setBounds(170,160,130,27);
		Lsalar.setBounds(075,210,77,27);
		Tsalar.setBounds(170,210,130,27);
		Bfind.setBounds(370,310,77,27);
		Bnew.setBounds(100,310,77,27);
		logo.setBounds(350,50,210,210);
		
		this.add(h3);
		this.add(Ldni);
		this.add(Tdni);
		this.add(Lnom);
		this.add(Tnom);
		this.add(Lape);
		this.add(Tape);
		this.add(logo);
		this.add(Lcity);
		this.add(lugares);
		this.add(Lsalar);
		this.add(Tsalar);
		this.add(Bnew);
		this.add(Bfind);
		
		Bnew.addActionListener(this);
		Bfind.addActionListener(this);
		smCity.addActionListener(this);
		smNom.addActionListener(this);
		smBor.addActionListener(this);
		smOUt.addActionListener(this);
		
		
		this.setVisible(true);
	}






	@Override
	public void actionPerformed(ActionEvent a) {
		// TODO Auto-generated method stub
         String eventoComando =a.getActionCommand();
		
		if(a.getSource() instanceof JButton){
			if(eventoComando=="BUSCAR"){
				try{
					
					String driver="com.mysql.cj.jdbc.Driver";
					String url="jdbc:mysql://asata400:3306/Tallerruben";
					String user="root";
					String password="toor";
					Connection con=null;
					PreparedStatement ps=null;
					ResultSet rs=null;
					String sql="select * from taller where dni=?";
					String dni=Tdni.getText();
					Class.forName(driver);
					con=DriverManager.getConnection(url,user,password);
					ps=con.prepareStatement(sql);
				    ps.setString(1,dni);
			        rs=ps.executeQuery();
		            while(rs.next()){
		            	    Tdni.setText(rs.getString("dni"));
			           		Tnom.setText(rs.getString("nombre"));
			           		Tape.setText(rs.getString("apellidos"));
			           	    lugares.setSelectedItem(rs.getString("ciudad"));
			           		Tsalar.setText(rs.getString("salario"));
		           		  	    
						       
							        
		               }
			        
					 rs.close();
		           
			   
			  
			
					      
				 
					
					
					
				
					
					
				
				
			}catch (Exception b){
				 System.out.println("ERROR "+ b.getMessage());
				
			 
			  }
			
		}else if(eventoComando=="NUEVO"){
				   try{
						String driver="com.mysql.cj.jdbc.Driver";
						String url="jdbc:mysql://asata400:3306/tallerruben";
						String user="root";
						String password="toor";
						Connection con=null;
						PreparedStatement ps=null;
						ResultSet rs=null;
						String sql="insert into `taller` values (?,?,?,?,?)";
					    int i=0;
					    String nombre=Tnom.getText();
						String dni=Tdni.getText();
						String apellido=Tape.getText();
						String salario=Tsalar.getText();
						int numero=lugares.getSelectedIndex();
						String ciudad=lugares.getItemAt(numero).toString();
						Class.forName(driver);
						con=DriverManager.getConnection(url,user,password);
						ps=con.prepareStatement(sql);
					    ps.setString(1,dni );
					    ps.setString(2,nombre );
					    ps.setString(3,apellido);
					    ps.setString(4,ciudad);
					    ps.setString(5,salario);
				        i=ps.executeUpdate();
				        if(i==0){
				        	 System.out.println("ERROR ");
							
						    	
						  }else{
							  
							  System.out.println("Exito"+i +" registros actualizados");
							  
						  }
								
				   
				   
			     


		       }catch(Exception c){
		    	   
		    	   System.out.println("ERROR "+c.getMessage());
		       }
			
			
			
			
		}
			
		
   }else if(a.getSource()instanceof JMenuItem){
		if(eventoComando.equals("B-CIUDAD")){
			TaleresvizcainaCity v4=new TaleresvizcainaCity(this);
			
			
		}else if(eventoComando.equals("B-NOMBRE")){
			TalleresvizcainaNom v3=new TalleresvizcainaNom(this);
		    this.setVisible(false);
		}else if(eventoComando.equals("Borrar")){
			 
			TalleresvizcainaBor v2= new TalleresvizcainaBor(this);
			
			
		}else if(eventoComando.equals("Cerrar")){
			   System.exit(0);
				
				
		}
	   
	   
      }
   }
	
}