package Taller;

public class TalleresvizcainaApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Talleresvizcaina v1=new Talleresvizcaina();
	}

}
