package chicas;

import java.awt.Color;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

public class Chicasfind extends JFrame implements ActionListener {
	

	
    private JLabel Lnombre;
	private JTextField Tnombre,Terrores;
	private JButton Binsertar;
    private JMenuBar bMenu;
	private JMenu mSalir;
	private JMenuItem smSalir;
	private JTable regis;
	private JScrollPane barra;
    private Chicasventana inicio;
    
	
	
	public Chicasfind(Chicasventana v) throws HeadlessException {
		super("VENTANA BUSQUEDA");
	    
		inicio =v;
		Lnombre=new JLabel("Nombre");
		Tnombre=new JTextField(15);
		Terrores=new JTextField(100);
		
		Binsertar=new JButton("HACER");
		
		bMenu=new JMenuBar();
		mSalir=new JMenu("Salir");
		mSalir.setMnemonic('s');
        smSalir=new JMenuItem("Cerrar",'c');
		
  
		bMenu.add(mSalir);
        mSalir.add(smSalir);
        
        this.getContentPane().setLayout(null);
		this.setBounds(250, 280,600,600);

		this.setJMenuBar(bMenu);
		Lnombre.setBounds(075,35,77,27);
		Tnombre.setBounds(130,35,130,27);
		Terrores.setBounds(075,5,500,27);
		Terrores.setEditable(false);
		Binsertar.setBounds(250,100,77,27);
		

		Binsertar.addActionListener(this);
		smSalir.addActionListener(this);
	
		

		this.add(Lnombre);
		this.add(Tnombre);
		this.add(Terrores);
	    this.add(Binsertar);
	
		this.setVisible(true);
		
		
	}



	@Override
	public void actionPerformed(ActionEvent a) {
		// TODO Auto-generated method stub
       String eventoComando =a.getActionCommand();
			
		   	if(a.getSource() instanceof JButton){
		   		if(eventoComando.equals("HACER")){
		   			
		   			try{
						String driver="com.mysql.cj.jdbc.Driver";
						String url="jdbc:mysql://localhost:3306/chicas";
						String user="root";
						String password="";
						Connection con=null;
						PreparedStatement ps=null;
						ResultSet rs=null;
				        String sql="select * from chicas where nombre=?";
				        String nombre=Tnombre.getText();
						String texto=null;
						Vector aux=null;
					    Vector filas=new Vector();
					    Vector columnas=new Vector();
					    columnas.addElement("Codigo");
					    columnas.addElement("Nombre");
					    columnas.addElement("Profesion");
					  
						 Class.forName(driver);
						con=DriverManager.getConnection(url,user,password);
						ps=con.prepareStatement(sql);
						 ps.setString(1,nombre );
				        rs=ps.executeQuery();
									 while(rs.next()){
										 aux=new Vector();
										 aux.addElement(""+rs.getString("Codigo"));
										 aux.addElement(rs.getString("Nombre"));
										 aux.addElement(""+rs.getString("Profesion"));
									
								         filas.add(aux);
								        
								}

						        regis=new JTable(filas,columnas);
							    barra=new JScrollPane(regis);
							    barra.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
							    barra.setBounds(075,130,400, 500);
								add(barra);
								rs.close();
						  
						
						
						
					
						
						
					
					
				}catch(Exception b){
					Terrores.setText("Error "+ b.getMessage());
					Terrores.setBackground(Color.PINK);
					Terrores.setFont(new Font("Verdana",Font.BOLD,17));   
					
					
				 
				  }
	   		
		   	}
	  }else if(a.getSource() instanceof JMenuItem) {
	   		if(eventoComando.equals("Cerrar")){
	   			
	   			inicio.setVisible(true);
	   			this.dispose();
	   		}
	   	
        }

	}
}


	
	
	


