package chicas;

public class ChicasApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Chicasventana v1=new Chicasventana();
		
	}

}
