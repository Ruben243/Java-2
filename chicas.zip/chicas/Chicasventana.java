package chicas;

import java.awt.Color;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;


public class Chicasventana extends JFrame implements ActionListener {
	private JLabel bienvenida;
    private JMenuBar bMenu;
	private JMenu mOps,mSalir;
	private JMenuItem smBuscar,smInsertar,smSalir;
	
	
 public Chicasventana() throws HeadlessException {
		super("VENTANA PRINCIPAL");
		
		bienvenida=new JLabel("BIENVENIDOS A MI APP");
		
		bienvenida.setBounds(150,100,300, 27);
		bienvenida.setFont(new Font("Verdana",Font.BOLD,20));
		bienvenida.setForeground(Color.RED);
		
		bMenu=new JMenuBar();
		mSalir=new JMenu("Salir");
		mOps=new JMenu("Opciones");
		mSalir.setMnemonic('s');
		      mOps.setMnemonic('o');
		
        smSalir=new JMenuItem("Cerrar",'c');
        smBuscar=new JMenuItem("Buscar",'b');
        smInsertar=new JMenuItem("Insertar",'i');
  
     
        
	
		bMenu.add(mOps);
		mOps.add(smBuscar);
		mOps.add(smInsertar);
	    bMenu.add(mSalir);
		
        mSalir.add(smSalir);

        this.setJMenuBar(bMenu);
		this.add(bienvenida);
		
		
		smBuscar.addActionListener(this);
		smInsertar.addActionListener(this);
		
		this.getContentPane().setLayout(null);
		this.setBounds(250, 280,600,300);

		smSalir.addActionListener(this);
		
		this.setVisible(true);
		
	}








	@Override
	public void actionPerformed(ActionEvent a) {
		// TODO Auto-generated method stub
		String eventoComando =a.getActionCommand();
		
		if(a.getSource()instanceof JMenuItem){
			if(eventoComando.equals("Buscar")){
				this.setVisible(false);
				Chicasfind v2=new Chicasfind(this);
				
			}else if(eventoComando.equals("Insertar")) {
				this.setVisible(false);
				Chicasinsertar v3=new Chicasinsertar(this);
				
				
			}else if(eventoComando.equals("Cerrar")) {
				System.exit(0);
			
			
			}
			
		
	    }
	
	

    }
}
