package chicas;

import java.awt.Color;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

public class Chicasinsertar extends JFrame implements ActionListener {
	
	private JLabel Lcodigo,Lnombre,Lprofession;
	private JTextField Tcodigo,Tnombre,Tprofession,Terrores;
	private JButton Binsertar;
    private JMenuBar bMenu;
	private JMenu mSalir;
	private JMenuItem smSalir;
	private JTable regis;
	private JScrollPane barra;
    private Chicasventana inicio;
	
	
	
	
	
	
	

	public Chicasinsertar(Chicasventana v) throws HeadlessException {
		super("Ventana insercion");
		inicio=v;
		Lcodigo=new JLabel("Codigo");
		Lnombre=new JLabel("Nombre");
		Lprofession=new JLabel("Profesion");
		
		Tcodigo=new JTextField(15);
		Tnombre=new JTextField(15);
		Tprofession=new JTextField(15);
		Terrores=new JTextField(100);
		
		Binsertar=new JButton("HACER");
		
		bMenu=new JMenuBar();
		mSalir=new JMenu("Salir");
		mSalir.setMnemonic('s');
        smSalir=new JMenuItem("Cerrar",'c');
		
  
		bMenu.add(mSalir);
        mSalir.add(smSalir);
        
        this.getContentPane().setLayout(null);
		this.setBounds(250, 280,600,1000);

		this.setJMenuBar(bMenu);
		Lcodigo.setBounds(075,50,77,27);
		Tcodigo.setBounds(130,50,130,27);
		Lnombre.setBounds(075,140,77,27);
		Tnombre.setBounds(130,140,130,27);
		Lprofession.setBounds(300,140,77,27);
		Tprofession.setBounds(400,140,130,27);
		Terrores.setBounds(075,5,500,27);
		Terrores.setEditable(false);
		Binsertar.setBounds(250, 200,77,27);
		

		Binsertar.addActionListener(this);
		smSalir.addActionListener(this);
	
		
		
		this.add(Lcodigo);
		this.add(Tcodigo);
		this.add(Lnombre);
		this.add(Tnombre);
		this.add(Lprofession);
		this.add(Tprofession);
		this.add(Terrores);
	    this.add(Binsertar);
	
		this.setVisible(true);
		
		
	}









	@Override
	public void actionPerformed(ActionEvent a) {
		// TODO Auto-generated method stub
     String eventoComando =a.getActionCommand();
		
	   	if(a.getSource() instanceof JButton){
	   		if(eventoComando.equals("HACER")){
	   			try{
					String driver="com.mysql.cj.jdbc.Driver";
					String url="jdbc:mysql://localhost:3306/chicas";
					String user="root";
					String password="";
					Connection con=null;
					PreparedStatement ps=null, ps1=null;
					ResultSet rs=null;
					String sql="insert into `chicas` values (?,?,?)";
					String sql2="select * from chicas";
					String texto=null;
				    int i=0;
				    String nombre=Tnombre.getText();
					int codigo=Integer.parseInt(Tcodigo.getText());
					String profesion=Tprofession.getText();
					Vector aux=null;
				    Vector filas=new Vector();
				    Vector columnas=new Vector();
				    columnas.addElement("Codigo");
				    columnas.addElement("Nombre");
				    columnas.addElement("Profesion");
				  
					 Class.forName(driver);
					con=DriverManager.getConnection(url,user,password);
					ps=con.prepareStatement(sql);
				    ps.setInt(1,codigo );
				    ps.setString(2,nombre );
				    ps.setString(3,profesion);
			        i=ps.executeUpdate();
			        if(i==0){
						 Terrores.setText("Error no se ha actualizado nada");
						 Terrores.setBackground(Color.PINK);
						 Terrores.setFont(new Font("Verdana",Font.BOLD,17));   
					
					    	
					    }else{
					    	     ps.close();
						    	 Terrores.setText("Exito "+i+" actualizados");
						    	 Terrores.setBackground(Color.BLUE);
								 Terrores.setFont(new Font("Verdana",Font.BOLD,17));  
							     ps1=con.prepareStatement(sql2);
								 
								 rs=ps1.executeQuery();
								 while(rs.next()){
									 aux=new Vector();
									 aux.addElement(""+rs.getString("Codigo"));
									 aux.addElement(rs.getString("Nombre"));
									 aux.addElement(""+rs.getString("Profesion"));
								
							         filas.add(aux);
							        
							}

					        regis=new JTable(filas,columnas);
						    barra=new JScrollPane(regis);
						    barra.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
						    barra.setBounds(075,300,400, 500);
							add(barra);
							rs.close();
					    } 
					
					
					
				
					
					
				
				
			}catch(Exception b){
				Terrores.setText("Error "+ b.getMessage());
				Terrores.setBackground(Color.PINK);
				Terrores.setFont(new Font("Verdana",Font.BOLD,17));   
				
				
			 
			  }
				
	   			
	   			
	   		}
	   		
	   		
	   	}else if(a.getSource() instanceof JMenuItem) {
	   		if(eventoComando.equals("Cerrar")){
	   			inicio.setVisible(true);
	   			this.dispose();
	   			
	   		}
	   	}
	   		
	}
		
}


