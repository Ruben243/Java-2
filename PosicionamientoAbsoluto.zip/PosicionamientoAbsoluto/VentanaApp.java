package PosicionamientoAbsoluto;

public class VentanaApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Ventana v1=new Ventana();
	}

}
