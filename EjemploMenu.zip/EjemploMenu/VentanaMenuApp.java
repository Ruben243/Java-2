package EjemploMenu;

public class VentanaMenuApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		VentanaMenu v1=new VentanaMenu();
		
	}

}
