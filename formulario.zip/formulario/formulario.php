<?php
include "encabezado.php";
if(isset($_SESSION["idusuario"])){

		echo"<form method='post' action=''>";
		echo "<label>Contraseña actual</label>";
		echo "<input type='text' name='actual'>";
		echo "<br>";
		echo "<label>Nueva contraseña</label>";
		echo "<input type='text' name='nueva'>";
		echo "<br>";
		echo "<label>Confirmar contraseña</label>";
		echo "<input type='text' name='confir'>";
		echo "<br>";
		echo" <input type='submit'>";
		echo"</form>";

	  if(isset($_REQUEST['actual'])){
	            $mensaje=''; 
		 	    $passAhash=hash("sha256",$_REQUEST['actual']);
			    $passNhash=hash("sha256",$_REQUEST['nueva']);
			    $passChash=hash("sha256",$_REQUEST['confir']);
				$mdb = new PDO("mysql:host=localhost;dbname=curso","usuariophp","clavephp");
				$sSQL = "SELECT idusuario FROM usuarios WHERE idusuario=? and clave=?";
				$consulta = $mdb->prepare($sSQL);
				$idusuario=$_SESSION["idusuario"];
				$consulta->bindParam(1,$idusuario);
				$consulta->bindParam(2,$passAhash);
				$consulta->execute();
				

				
      if (!$consulta){
		$mensaje.="La contraseña actual no es correcta<br />";
	}
	
	if ( $passNhash != $passChash){
		$mensaje.="Las contraseñas no coinciden<br />";
	}
	if ($passNhash==""){
		$mensaje.="La nueva contraseña no puede estar en blanco<br />";
	}
	if ($passNhash== $passAhash){
		$mensaje.="La nueva contraseña no puede ser igual a la anterior<br />";
	}
	
	if ($mensaje == ""){
		// Cambiar la contraseña en la BD
		$sSQL = "UPDATE usuarios SET clave=? WHERE idusuario=?";
		$consulta = $mdb->prepare($sSQL);
     	$idusuario = $_SESSION["idusuario"];
		$consulta->bindParam(1,$passNhash);
		$consulta->bindParam(2,$idusuario);
		$consulta->execute();
	
		if (!$fila)
		{
			$mensaje.="La contraseña actual no es correcta<br />";
		}

	}
	else
	{
		echo "<p class='ERROR'>".$mensaje."</p>";
	}
	$consulta=null;
	$mdb=null;

 
        
	  }
	  include "pie.php";

}
?>