﻿<?php
include "encabezado.php";

echo "<p>HOLA, esta es la página pública, concretamente la home</p>";

include "pie.php";

?>