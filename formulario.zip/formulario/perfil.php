<?php
include "encabezado.php";

$mensaje="";
$mensaje2="";
if (isset($_REQUEST["nombre"])){
	$nombre = $_REQUEST["nombre"];
	$nombre=trim($nombre);
	if ($nombre==""){
		$mensaje.="El nombre no puede estar en blanco<br />";
	}

	if(isset($_REQUEST['email'])){
		$email=$_REQUEST['email'];
        if ($email==""){
          $mensaje.="El email no puede estar en blanco<br />";
	    }
	
	if ($mensaje=="" ){
		$mdb = new PDO($database,$userDB,$passDB);
		$sSQL = "UPDATE usuarios SET nombre=?,email=? WHERE idusuario=?";
		$consulta = $mdb->prepare($sSQL);
		$idusuario = $_SESSION["idusuario"];
		$consulta->bindParam(1,$nombre);
		$consulta->bindParam(2,$email);
		$consulta->bindParam(3,$idusuario);
		$consulta->execute();
		if ($consulta->rowCount()>0){
			$mensaje.="Nombre modificado correctamente";
			$mensaje.="Email modificado correctamente";
			$_SESSION["nombre"]=$nombre;
		}
		
	   }
	}
}

if(isset($_Files['foto'])){
    $photo=$_Files['foto'];
	$sSQL = "UPDATE usuarios SET  foto=? WHERE idusuario=?";
    $consulta = $mdb->prepare($sSQL);
	$idusuario = $_SESSION["idusuario"];
	$consulta->bindParam(1,$photo);
	$consulta->bindParam(2,$idusuario);
	$consulta->execute();
    	if ($consulta->rowCount()>0){
			$mensaje.="Foto modificado correctamente";
			$_Files['foto']=$photo;
		}
		
}



$consulta=null;
$mdb = null;
				
       

echo "<p class='ERROR'>".$mensaje."</p>";
echo "<form class='chgProfile' method='POST' action=''>";
echo"<p>";
echo "<label for='nombre'>Nombre de Usuario:</label>";
echo "<input name='nombre' id='nombre' value='".$_SESSION["nombre"]."' />";
echo"</p>";
echo"<p>";
echo "<label for='foto'>Foto de Perfil:</label>";
echo "<input name='foto' id='foto' value='' type='file' />";
echo"</p>";
echo"<p>";
echo "<label for='email'>Email de Perfil:</label>";
echo "<input type='email' name='email' value=".$email.">";
echo"</p>";
echo"<p>";
echo "<input type='submit' value='Guardar Datos' />";
echo"</p>";
echo "</form>";

include "pie.php";
?>