<?php session_start();
	
$success = isset($_SESSION["idusuario"]);
	// Inicializo variables de configuración
	$database = "mysql:host=localhost;dbname=curso";
	$userDB = "usuariophp";
	$passDB = "clavephp";

	if ($success){
		$fotoPerfil = "fotos/noname.jpg";
		$mdb = new PDO($database,$userDB,$passDB);
		$sSQL = "SELECT foto FROM usuarios WHERE idusuario=?";
		$consulta = $mdb->prepare($sSQL);
		$idusuario = $_SESSION["idusuario"];
		$consulta->bindParam(1,$idusuario);
		$consulta->execute();
		$fila=$consulta->fetch();
		if ($fila){
			if ($fila["foto"]!=""){
				$fila["foto"]=$fotoPerfil;
			}
		}
		$consulta=null;
		$mdb = null;
		
		$opcionMenu = "<li><a href='/ruben/formulario/logout.php'>Cerrar Sesión</a></li>";
		$opcionMenu.="<li><a href='/ruben/formulario/cambiarUser.php'>Cambiar usuario</a></li>";
		$opcionMenu.="<li><a href='/ruben/formulario/perfil.php'>Perfil</a></li>";
		$fotoPerfil = "<div id='fotoUsuario'><img src='".$fotoPerfil."' /></div>";
		$saludo = "<div id='saludo'>".$_SESSION["nombre"]."</div>";
		
	}
	else {
		$opcionMenu = "<li><a href='/ruben/formulario/login.php'>Iniciar Sesión</a></li>";
		$saludo = "";
	}
	
	
	
?>

<html>
<head>
<link rel="stylesheet" type="text/css" href="/ruben/formulario/css/mycss.css" />
</head>
<body>
<header>
<?php 
echo $fotoPerfil;
echo $saludo;
?>
<nav>
<ul>
<li><a href="/ruben/formulario/index.php">Inicio</a></li>
<li><a href="/ruben/char/chat.php"></a></li>
<?php echo $opcionMenu ?>

</ul>
</nav>
</header>
<section>
